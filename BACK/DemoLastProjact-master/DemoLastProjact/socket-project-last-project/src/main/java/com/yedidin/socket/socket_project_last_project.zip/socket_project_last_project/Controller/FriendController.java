package com.yedidin.socket.socket_project_last_project.Controller;

import com.yedidin.socket.socket_project_last_project.Entity.Event;
import com.yedidin.socket.socket_project_last_project.Entity.User;
import com.yedidin.socket.socket_project_last_project.Service.EventService;
import com.yedidin.socket.socket_project_last_project.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/friend")
@PreAuthorize("hasRole('FRIEND')")
@CrossOrigin(origins = "*")
public class FriendController {


    private final EventService eventService;
    private final UserService userService;

    public FriendController(EventService eventService, UserService userService) {
        this.eventService = eventService;
        this.userService = userService;
    }

    // קבלת פרטי המשתמש המחובר
    @GetMapping("/me")
    public ResponseEntity<?> getUserProfile() {
        User currentUser = userService.getCurrentUser();
        return ResponseEntity.ok(Map.of(
                "id", currentUser.getId(),
                "firstName", currentUser.getFirstName(),
                "lastName", currentUser.getLastName(),
                "email", currentUser.getEmail()
        ));
    }

    // קבלת כל האירועים שהחבר מוקצה אליהם
    @GetMapping("/assigned-events")
    public ResponseEntity<List<Event>> getAssignedEvents() {
        Long currentUserId = userService.getCurrentUser().getId();
        List<Event> events = eventService.findByFriendId(currentUserId);
        return ResponseEntity.ok(events);
    }

    // קבלת אירוע ספציפי
    @GetMapping("/events/{eventId}")
    public ResponseEntity<?> getEvent(@PathVariable Long eventId) {
        User currentUser = userService.getCurrentUser();
        Event event = eventService.getEventById(eventId);

        // בדיקה שהאירוע מוקצה לחבר הנוכחי
        if (event.getFriend() == null || !event.getFriend().getId().equals(currentUser.getId())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("אין לך הרשאה לצפות באירוע זה");
        }

        return ResponseEntity.ok(event);
    }

    // עדכון סטטוס של אירוע
    @PutMapping("/events/{eventId}/status")
    public ResponseEntity<?> updateEventStatus(
            @PathVariable Long eventId,
            @RequestBody Map<String, String> statusUpdate) {

        User currentUser = userService.getCurrentUser();
        Event event = eventService.getEventById(eventId);

        // בדיקה שהאירוע מוקצה לחבר הנוכחי
        if (event.getFriend() == null || !event.getFriend().getId().equals(currentUser.getId())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("אין לך הרשאה לעדכן אירוע זה");
        }

        if (statusUpdate.containsKey("isDone")) {
            event.setIsDone(statusUpdate.get("isDone"));
            eventService.saveEvent(event);
            return ResponseEntity.ok("סטטוס האירוע עודכן בהצלחה");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("חובה לציין סטטוס");
        }
    }
}
