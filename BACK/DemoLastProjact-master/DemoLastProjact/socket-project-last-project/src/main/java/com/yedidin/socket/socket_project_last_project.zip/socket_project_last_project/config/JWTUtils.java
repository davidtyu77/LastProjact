package com.yedidin.socket.socket_project_last_project.config;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;

import javax.crypto.SecretKey;
import java.security.SecureRandom;
import java.util.Base64;
import java.util.Date;

public class JWTUtils {



    private final SecretKey secretKey;
    private final long expirationTime = 864_000_000;

    public JWTUtils() {
        SecureRandom random = new SecureRandom();
        byte[] keyBytes = new byte[32]; // 256-bit key
        random.nextBytes(keyBytes);
        this.secretKey = Keys.hmacShaKeyFor(keyBytes);    }
    // יצירת JWT
    public String generateToken(String email, String role) {
        return Jwts.builder()
                .setSubject(email)
                .claim("role", role)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expirationTime))
                .signWith(SignatureAlgorithm.HS256, secretKey)
                .compact();
    }

    public String extractByEmail(String token) {
        return Jwts.parser()
                .setSigningKey(secretKey)
                .build()
                .parseClaimsJws(token)
                .getBody()
                .getSubject();
    }

    // אימות ופריסת JWT
    public Claims validateToken(String token) {
        JwtParser parser = Jwts.parser()
                .setSigningKey(secretKey)
                .build();  // בונים את ה-JwtParser

        return parser.parseClaimsJws(token)   // קריאה ל-parseClaimsJws()
                .getBody();
    }

    // לקבלת שם המשתמש מתוך ה-JWT
    public String getUsernameFromToken(String token) {
        return validateToken(token).getSubject();
    }

    // לקבלת התפקיד מתוך ה-JWT
    public String getRoleFromToken(String token) {
        return (String) validateToken(token).get("role");

    }

    // בדיקה אם ה-JWT עדיין תקף
    public boolean isTokenExpired(String token) {
        return validateToken(token).getExpiration().before(new Date());
    }

    public SecretKey getSecretKey() {
        return secretKey;
    }
}
