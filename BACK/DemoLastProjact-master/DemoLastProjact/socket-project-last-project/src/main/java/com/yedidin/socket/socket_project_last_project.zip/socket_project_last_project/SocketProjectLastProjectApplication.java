package com.yedidin.socket.socket_project_last_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocketProjectLastProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SocketProjectLastProjectApplication.class, args);
		System.out.println("Server is running");
	}

}
