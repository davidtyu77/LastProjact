package com.yedidin.socket.socket_project_last_project.chat;

public enum AlertType {

    CHAT,
    JOIN,
    LEAVE
}
