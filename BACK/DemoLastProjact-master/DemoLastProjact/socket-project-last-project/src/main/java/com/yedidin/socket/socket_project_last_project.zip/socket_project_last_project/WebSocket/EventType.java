package com.yedidin.socket.socket_project_last_project.WebSocket;

public enum EventType {

        NEW_REQUEST,     // בקשה חדשה נוצרה
        REQUEST_UPDATE,  // בקשה קיימת התעדכנה
        REQUEST_CLOSED,  // בקשה נסגרה
        VOLUNTEER_JOINED // מתנדב הצטרף

}
