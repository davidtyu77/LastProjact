package com.yedidin.socket.socket_project_last_project.WebSocket;

public enum ActionType {
    REQUEST_HELP,      // משתמש ביקש עזרה
    VOLUNTEER_ACCEPT,  // מתנדב קיבל את הבקשה
    VOLUNTEER_ARRIVED, // מתנדב הגיע למיקום
    HELP_COMPLETED     // העזרה הושלמה
}